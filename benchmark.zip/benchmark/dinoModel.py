from baseModel import *

class DinoModel(BaseModel):
    def __init__(self, name: str, version='facebook/dinov2-base'):
        self.version = version
        super().__init__(name = name)

    def _build_model(self):
        self.processor = AutoImageProcessor.from_pretrained(self.version)
        self.model = AutoModel.from_pretrained(self.version)
        self.model.eval()

    def get_output(self, input_image):
        inputs = self.processor(images=input_image, return_tensors="pt").to(self.device)
        outputs = self.model(**inputs)
        return outputs.last_hidden_state

    def preprocess_image(self, image_path):
        image = Image.open(image_path).convert('RGB')
        return image